export { default } from "./Comment";
