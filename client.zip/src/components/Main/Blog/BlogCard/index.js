export { default } from "./BlogCard";
